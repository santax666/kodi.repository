# -*- coding: utf-8 -*-

from urllib.parse import parse_qs, urlencode
from sys import argv
import requests
import html
import re

import xbmcgui
import xbmcaddon
import xbmcplugin


ADDON_NAME =   'plugin.video.culture'
ADDON      =   xbmcaddon.Addon(id=ADDON_NAME)
URL = argv[0]
HANDLE = int(argv[1])


sort_setting = ADDON.getSetting('sort')
sort_direction_setting = ADDON.getSetting('sort_direction')
items_on_page = int(ADDON.getSetting('items_on_page'))
sort_dict = {'По популярности': 'views', 'По году': 'year', 'По алфавиту': 'title', 'По дате премьеры': 'publishDate'}
sort_direction_dict = {'По возрастанию': '', 'По убыванию': '-'}
sorting = sort_dict[sort_setting]
sort_direction = sort_direction_dict[sort_direction_setting]


def get_params():
    param_string = argv[2][1:]
    return dict(parse_qs(param_string))


def main_menu():
    menu_items = [
        ('Спектакли', {'action': 'theaters/performances', 'rubricid': 294}),
        ('Концерты', {'action': 'music/concerts', 'rubricid':516}),
        ('Лекции', {'action': 'lectures/movies', 'rubricid':559}),
        ('Фильмы', {'action': 'cinema/movies', 'rubricid':554}),
        ('Поиск', {'action': 'search', 'rubric': '', 'rubricid': ''}),
    ]
    for title, params in menu_items:
        list_item = xbmcgui.ListItem(label=title)
        url_with_params = f"{URL}?{urlencode(params)}"
        if title != 'Поиск':
            rubrics = get_children_rubrics(params['rubricid'])
            context_menu_items = [(x[0],f'Container.Update({URL}?action={x[1]})') for x in rubrics]
            list_item.addContextMenuItems(context_menu_items)
        xbmcplugin.addDirectoryItem(HANDLE, url=url_with_params, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def show_videos(movies,cur_page,total_page,movie_name='',institute=''):
    xbmcplugin.setPluginCategory(HANDLE, 'Видео')
    xbmcplugin.setContent(HANDLE, 'videos')
    for movie in movies:
        list_item = xbmcgui.ListItem(movie['title'])
        list_item.setContentLookup(False)
        fanart = movie.get('thumbnailFile',False)
        if fanart:
            img_url = get_photo_url(fanart['publicId'],fanart['width'],fanart['height'],fanart['originalName'])
            list_item.setArt({'fanart': img_url, 'thumb': img_url})
        tags = list_item.getVideoInfoTag()
        set_video_info(tags,movie)
        for material in [x for x in movie['materials'] if x['type']=='video']:
            video_url = get_video_url(material['player'] or material['files'])
            list_item.setLabel(material['title'])
            if movie.get('institute',False):
                context_menu_items = [(f'Трансляции от {movie["institute"]["title"]}',f'Container.Update({URL}?action=institute_broadcasts&institute={movie["institute"]["_id"]})')]
                list_item.addContextMenuItems(context_menu_items)            
            xbmcplugin.addDirectoryItem(HANDLE, video_url, list_item)
    if cur_page != total_page:
        list_item = xbmcgui.ListItem(' ─────► ')
        url_with_params = f'{URL}?action={action}&page={cur_page+1}&movie_name={movie_name}&institute={institute}'
        xbmcplugin.addDirectoryItem(HANDLE, url=url_with_params, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE, updateListing=False)


def set_video_info(tags,movie):
    tags.setTitle(movie['title'])
    tags.setYear(int(movie['year']))
    tags.setOriginalTitle(movie['originalTitle'])
    tags.setPlot(filter_description(movie['text']))
    tags.setPlotOutline(filter_description(movie.get('shortText','')))
    tags.setMpaa(str(movie['ageRestriction']))
    tags.setPremiered(movie['publishDate'])
    tags.setDuration(movie['duration'] or 0)
    tags.setCountries([x['title'] for x in movie['countries']])
    tags.setGenres([x['title'] for x in movie['genres']])
    tags.setTags([x['title'] for x in movie['tags']])
    tags.setDirectors([x['person']['title'] for x in movie['participants'] if x['type']['name']=='director'])
    tags.setStudios([movie['productionCompanies'] or movie['organizationName']])
    actors = []
    for ind,x in enumerate([y for y in movie['participants'] if y['type']['name']!='director'],1):
        actor_name = x['person']['title']
        actor_role = x['type']['title']
        actor_photo = x['person'].get('thumbnailFile',False)
        if actor_photo:
            actor_url = get_photo_url(actor_photo['publicId'],actor_photo['width'],actor_photo['height'],actor_photo['originalName'])
        else:
            actor_url = ''
        actors.append(xbmc.Actor(actor_name,actor_role,order=ind,thumbnail=actor_url))
    tags.setCast(actors)


def get_photo_url(pid,w,h,img):
    return f"https://cdn.culture.ru/images/{pid}/w_{w},h_{h}/{img}"
    

def get_video_url(video_info):
    url = ''
    if isinstance(video_info, str):
        player = video_info
    elif len(video_info)==1:
        player = video_info[0]['publicId']
    else:
        return ''
    player = html.unescape(player)
    if 'youtube' in player:
        match = re.findall(r'src=\"https://www\.youtube\.com/embed/([^\"]+)\"', player)
        if match:
            url = f'plugin://plugin.video.youtube/play/?video_id={match[0]}'
    elif 'video_ext' in player:
        match = re.findall(r'oid=(-?\d+)&id=(\d+)',player)
        if match:
            code1,code2 = match[0]
            url = f'plugin://plugin.video.zeltorix.vk.video//?router=play&data={code1}_{code2}'
    elif 'rutube' in player:
        match = re.findall(r'src=\"https://rutube\.ru/play/embed/([^\"]+)/\"', player)
        if match:
            url = f'plugin://plugin.video.zeltorix.rutube/?router=play&data={match[0]}'
    elif 'ok.ru' in player:
        match = re.findall(r'src=\"//ok\.ru/videoembed//(\d+)\?', player)
        if match:
            url = f'plugin://plugin.video.zeltorix.ok.video//?router=play&data=https://ok.ru/video/{match[0]}'
    else:
        url = f"https://video-playlist.culture.ru{player}"
    return url
    

def filter_description(desc):
    desc = re.sub(r'\[(URLEXTERNAL|URL)=[^\]]*\](.*?)\[/\1\]', r'\2', desc)
    desc = re.sub(r'\[ФОТОВРЕЗКА\].*?\[/ФОТОВРЕЗКА\]', '', desc, flags=re.DOTALL)
    desc = re.sub(r'\[/?(ЦИТАТА|TEXT|HTML|B)\]', '', desc)
    desc = re.sub(r'\[ВКЛАДКИ\]|\[ВКЛАДКА=[^\]]*\]|\[/ВКЛАДКА\]', '', desc)
    desc = re.sub(r'\[ВКЛАДКИ\]|\[ВКЛАДКА=[^\]]*\]|\[/ВКЛАДКА\]|\[/ВКЛАДКИ\]', '', desc)
    desc = re.sub(r'<.*?>', '', desc)
    desc = re.sub(r'&\w+;', ' ', desc)
    return desc


def get_children_rubrics(rubricid):
    rubrics = {
        294: [('Моноспектакль', 'theaters/performances/one-actor'), ('Балет', 'theaters/performances/ballet'), ('Опера', 'theaters/performances/opera'), ('Оперетта', 'theaters/performances/operetta'), ('Мюзикл', 'theaters/performances/musical'), ('Драма', 'theaters/performances/drama'), ('Кукольный спектакль', 'theaters/performances/kukolnyi-spektakl'), ('Детский спектакль', 'theaters/performances/detskii-spektakl'), ('Творческий вечер', 'theaters/performances/tvorcheskii-vecher'), ('Экспериментальный спектакль', 'theaters/performances/eksperimentalnyi-spektakl'), ('Комедия', 'theaters/performances/komediya'), ('Цирк', 'theaters/performances/circus'), ('Живой архив. Студенческая среда', 'theaters/performances/theatre-school')],
        516: [('Классика', 'music/concerts/classic'), ('Гала-концерт', 'music/concerts/gala-concert'), ('Для детей', 'music/concerts/dlya-detei'), ('Народная музыка', 'music/concerts/narodnaya-muzyka'), ('Танец', 'music/concerts/tanec'), ('Авторская песня', 'music/concerts/avtorskaya-pesnya'), ('Джаз', 'music/concerts/jazz'), ('Детский хор', 'music/concerts/detskii-khor'), ('Эстрада', 'music/concerts/estrada'), ('Авангард', 'music/concerts/avangard'), ('Акустика', 'music/concerts/akustika'), ('Блюз', 'music/concerts/blues'), ('Вечер памяти', 'music/concerts/vecher-pamyati'), ('Госпел', 'music/concerts/gospel'), ('Диско', 'music/concerts/disko'), ('Кавер', 'music/concerts/cover'), ('Панк', 'music/concerts/punk'), ('Поп', 'music/concerts/pop'), ('Регги', 'music/concerts/reggae'), ('Рок-н-ролл', 'music/concerts/rock-n-roll'), ('Соул', 'music/concerts/soul'), ('Фанк', 'music/concerts/funk'), ('Фьюжн', 'music/concerts/fusion'), ('Церковная музыка', 'music/concerts/cerkovnaya-muzyka'), ('Электроника', 'music/concerts/elektronika')],
        559: [('Технологии', 'lectures/movies/technologies'), ('Наука', 'lectures/movies/science'), ('История', 'lectures/movies/history'), ('Изобразительное искусство', 'lectures/movies/art'), ('Музыка', 'lectures/movies/music'), ('Литература и язык', 'lectures/movies/literatura-i-yazyk'), ('Архитектура', 'lectures/movies/architecture'), ('Театр', 'lectures/movies/theater'), ('Кино', 'lectures/movies/cinema'), ('PRO.Культура.РФ', 'lectures/movies/pro-kultura-rf'), ('Интернет-маркетинг', 'lectures/movies/pro-kultura-rf/internet-marketing'), ('Цифровые технологии', 'lectures/movies/pro-kultura-rf/cifrovye-tekhnologii'), ('Профессии в сфере культуры', 'lectures/movies/pro-kultura-rf/professii-v-sfere-kultury'), ('Всероссийские и сетевые акции', 'lectures/movies/pro-kultura-rf/vserossiiskie-i-setevye-akcii'), ('Платформа «PRO.Культура.РФ»', 'lectures/movies/pro-kultura-rf/platforma-pro-kultura-rf'), ('100 лекций для школьников о кино', 'lectures/movies/cinema/100'), ('Мастер-классы', 'lectures/movies/master-class'), ('Профессиональные уроки', 'lectures/movies/master-class/profi'), ('Своими руками', 'lectures/movies/master-class/svoimi-rukami'), ('Экскурсии', 'lectures/movies/ekskursii'), ('Пушкинская карта', 'lectures/movies/pro-kultura-rf/pushkinskaya-karta')],
        554: [('Документальное', 'cinema/movies/documentary'), ('Драма', 'cinema/movies/drama'), ('Биография', 'cinema/movies/bio'), ('Детское', 'cinema/movies/child'), ('Мультфильм', 'cinema/movies/cartoons'), ('Боевик', 'cinema/movies/boevik'), ('Военное', 'cinema/movies/war'), ('Детектив', 'cinema/movies/detektiv'), ('Историческое', 'cinema/movies/history'), ('Комедия', 'cinema/movies/comedy'), ('Мелодрама', 'cinema/movies/melodrama'), ('Мюзикл', 'cinema/movies/musical'), ('Приключения', 'cinema/movies/adventure'), ('Семейное', 'cinema/movies/family'), ('100 фильмов для школьников', 'cinema/movies/family/child-100'), ('Сказка', 'cinema/movies/skazka'), ('Триллер', 'cinema/movies/thriller'), ('Фантастика', 'cinema/movies/fantastic'), ('Фэнтези', 'cinema/movies/fantasy'), ('Открытая коллекция', 'cinema/movies/open-collection'), ('Кино регионов', 'cinema/movies/kino-regionov'), ('Культурный фронт', 'cinema/movies/kulturnyi-front')]
    }
    return rubrics[rubricid]
    

def search_movies(movie_name='',rubric='',page=1, institute=''):
    params = {
        'fields': 'title,thumbnailFile,materials,originalTitle,text,duration,genres,participants,countries,productionCompanies,year,tags,organizationName,ageRestriction,publishDate,institute',
        'sort': f'{sort_direction}{sorting}',
        'limit': items_on_page,
        'page': page,
        'cached': 'true',
    }
    if institute:
        params['institutes']=institute
        url = f'https://www.culture.ru/api/broadcast'
    else:
        params['query']=movie_name
        params['rubricPath']=rubric
        url = f'https://www.culture.ru/api/movies'
    try:
        body = requests.get(url,params=params,headers={'user-agent': 'Mozilla/5.0'},timeout=items_on_page).json()
    except:
        return xbmcgui.Dialog().notification('Поиск', f'Ошибка обращения к серверу, попробуйте позднее', xbmcgui.NOTIFICATION_INFO, 3000)
    movies = [x for x in body['items'] if x['materials']]
    if movies:
        show_videos(movies,body['pagination']['current'],body['pagination']['total'],movie_name=movie_name,institute=institute)
    else:
        xbmcgui.Dialog().notification('Поиск', f'По запросу ничего не найдено.', xbmcgui.NOTIFICATION_INFO, 3000)



def search_dialog():
    movie_name = xbmcgui.Dialog().input("Введите запрос для поиска")
    if movie_name:
        search_movies(movie_name=movie_name)


if __name__ == '__main__':
    params = get_params()
    action = params.get('action', [None])[0]
    rubric = params.get('rubric', [None])[0]
    movie_name = params.get('movie_name', [''])[0]
    institute = params.get('institute', [''])[0]
    page = params.get('page', ['1'])[0]
    if int(page) > 1:
        if institute:
            search_movies(institute=institute,page=page)
        else:
            search_movies(movie_name=movie_name,page=page) if movie_name else search_movies(rubric=action,page=page)
    elif action == 'search':
        search_dialog()
    elif action is None:
        main_menu()
    else:
        search_movies(rubric=action,institute=institute)

