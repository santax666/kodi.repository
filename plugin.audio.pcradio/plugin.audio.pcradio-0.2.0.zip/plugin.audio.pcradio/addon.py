import os
import sys
import json
import zipfile
import shutil
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import urllib.request
import urllib.parse
import urllib.error
import ssl
from xbmcvfs import translatePath
from pathlib import Path


# Инициализация аддона
addon = xbmcaddon.Addon()
addon_id = addon.getAddonInfo('id')
addon_name = addon.getAddonInfo('name')
addon_path = addon.getAddonInfo('path')
addon_profile = translatePath(addon.getAddonInfo('profile'))


# URL для скачивания архива (можно изменить в настройках)
ARCHIVE_URL = 'http://stream.pcradio.ru/list/list_ru/list_old_ru.zip'
# Пароль архива (встроенный в код, не хранится в настройках)
ARCHIVE_PASSWORD = '78951233215987'  # Замените на ваш пароль

# Пути к файлам
JSON_FILENAME = 'list.json'
JSON_FILE_PATH = os.path.join(addon_profile, JSON_FILENAME)
TEMP_ARCHIVE_PATH = os.path.join(addon_profile, 'temp_data.zip')
FAVORITES_FILE_PATH = os.path.join(addon_profile, 'favorites.json')


# Создаем папку профиля, если её нет
if not os.path.exists(addon_profile):
    os.makedirs(addon_profile)

def log(message, level=xbmc.LOGINFO):
    """Логирование сообщений"""
    xbmc.log(f"[{addon_id}] {message}", level)

def download_and_extract_archive():
    """Скачивание и распаковка архива"""
    try:
        log("Начинаем скачивание архива...")
        
        # Скачиваем архив
        context = ssl._create_unverified_context() if hasattr(ssl, '_create_unverified_context') else None
        req = urllib.request.Request(ARCHIVE_URL)
        
        if context:
            response = urllib.request.urlopen(req, context=context)
        else:
            response = urllib.request.urlopen(req)
        
        with open(TEMP_ARCHIVE_PATH, 'wb') as f:
            f.write(response.read())
        
        log(f"Архив скачан: {TEMP_ARCHIVE_PATH}")
        
        # Распаковываем архив с паролем
        with zipfile.ZipFile(TEMP_ARCHIVE_PATH, 'r') as zip_ref:
            # Пытаемся извлечь с паролем
            try:
                zip_ref.extractall(addon_profile, pwd=ARCHIVE_PASSWORD.encode('utf-8'))
                log("Архив успешно распакован")
            except RuntimeError as e:
                log(f"Ошибка при распаковке с паролем: {str(e)}", xbmc.LOGERROR)
                # Пробуем без пароля (для обратной совместимости)
                try:
                    zip_ref.extractall(addon_profile)
                    log("Архив распакован без пароля")
                except Exception as e2:
                    log(f"Ошибка при распаковке без пароля: {str(e2)}", xbmc.LOGERROR)
                    raise Exception("Не удалось распаковать архив. Неверный пароль или поврежденный архив.")
        
        # Удаляем временный архив
        if os.path.exists(TEMP_ARCHIVE_PATH):
            os.remove(TEMP_ARCHIVE_PATH)
        
        # Проверяем, что JSON файл создан
        if not os.path.exists(JSON_FILE_PATH):
            # Ищем JSON файл в распакованных файлах
            json_found = False
            for root, dirs, files in os.walk(addon_profile):
                for file in files:
                    if file.endswith('.json'):
                        json_path = os.path.join(root, file)
                        shutil.move(json_path, JSON_FILE_PATH)
                        json_found = True
                        log(f"Найден и перемещен JSON файл: {file}")
                        break
                if json_found:
                    break
            
            if not json_found:
                raise Exception("В архиве не найден JSON файл")
        
        return True
        
    except Exception as e:
        log(f"Ошибка при скачивании/распаковке: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            addon_name,
            'Ошибка при обновлении данных',
            xbmcgui.NOTIFICATION_ERROR,
            5000
        )
        return False

def load_radio_data():
    """Загрузка данных о радиостанциях из JSON файла"""
    if not os.path.exists(JSON_FILE_PATH):
        log("JSON файл не найден, пытаемся скачать...")
        if not download_and_extract_archive():
            return None
    
    try:
        with open(JSON_FILE_PATH, 'r', encoding='utf-8') as f:
            data = json.load(f)
        log(f"Данные загружены из {JSON_FILE_PATH}")
        return data
    except Exception as e:
        log(f"Ошибка при чтении JSON: {str(e)}", xbmc.LOGERROR)
        return None

def show_main_menu():
    """Показать главное меню"""
    # Мои станции
    list_item = xbmcgui.ListItem(label='[COLOR magenta]Мои станции[/COLOR]')
    list_item.setArt({'icon': 'DefaultFavourites.png'})
    xbmcplugin.addDirectoryItem(
        handle=int(sys.argv[1]),
        url=f'plugin://{addon_id}/?action=favorites',
        listitem=list_item,
        isFolder=True
    )

    # Страны
    list_item = xbmcgui.ListItem(label='[COLOR blue]По странам[/COLOR]')
    list_item.setArt({'icon': 'DefaultCountry.png'})
    xbmcplugin.addDirectoryItem(
        handle=int(sys.argv[1]),
        url=f'plugin://{addon_id}/?action=countries',
        listitem=list_item,
        isFolder=True
    )
    
    # Жанры
    list_item = xbmcgui.ListItem(label='[COLOR green]По жанрам[/COLOR]')
    list_item.setArt({'icon': 'DefaultGenre.png'})
    xbmcplugin.addDirectoryItem(
        handle=int(sys.argv[1]),
        url=f'plugin://{addon_id}/?action=genres',
        listitem=list_item,
        isFolder=True
    )
    
    # Города
    list_item = xbmcgui.ListItem(label='[COLOR orange]По городам[/COLOR]')
    list_item.setArt({'icon': 'DefaultCity.png'})
    xbmcplugin.addDirectoryItem(
        handle=int(sys.argv[1]),
        url=f'plugin://{addon_id}/?action=cities',
        listitem=list_item,
        isFolder=True
    )
    
    # Все станции
    list_item = xbmcgui.ListItem(label='[COLOR yellow]Все станции[/COLOR]')
    list_item.setArt({'icon': 'DefaultMusic.png'})
    xbmcplugin.addDirectoryItem(
        handle=int(sys.argv[1]),
        url=f'plugin://{addon_id}/?action=all_stations',
        listitem=list_item,
        isFolder=True
    )
    
    # Поиск
    list_item = xbmcgui.ListItem(label='[COLOR yellow]Поиск по названию[/COLOR]')
    list_item.setArt({'icon': 'DefaultAddonsSearch.png'})
    xbmcplugin.addDirectoryItem(
        handle=int(sys.argv[1]),
        url=f'plugin://{addon_id}/?action=input_search',  # Новое действие: только запрос ввода
        listitem=list_item,
        isFolder=False  # ВАЖНО: False, чтобы Kodi не ждал открытия каталога
    )
    
    # Обновить данные
    list_item = xbmcgui.ListItem(label='[COLOR lightblue]Обновить данные с сервера[/COLOR]')
    list_item.setArt({'icon': 'DefaultAddonUpdate.png'})
    xbmcplugin.addDirectoryItem(
        handle=int(sys.argv[1]),
        url=f'plugin://{addon_id}/?action=update',
        listitem=list_item,
        isFolder=False
    )
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def show_countries():
    """Показать список стран"""
    data = load_radio_data()
    if not data:
        return
     
    for country in data['countries']:
        list_item = xbmcgui.ListItem(label=country['name'])
        list_item.setArt({'icon': 'DefaultCountry.png'})
        xbmcplugin.addDirectoryItem(
            handle=int(sys.argv[1]),
            url=f'plugin://{addon_id}/?action=country_stations&country={country["id"]}',
            listitem=list_item,
            isFolder=True
        )
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def show_genres():
    """Показать список жанров"""
    data = load_radio_data()
    if not data:
        return

    for genre in data['genres']:
        list_item = xbmcgui.ListItem(label=genre['name'])
        list_item.setArt({'icon': 'DefaultGenre.png'})
        xbmcplugin.addDirectoryItem(
            handle=int(sys.argv[1]),
            url=f'plugin://{addon_id}/?action=genre_stations&genre={genre["id"]}',
            listitem=list_item,
            isFolder=True
        )
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def show_cities():
    """Показать список городов"""
    data = load_radio_data()
    if not data:
        return

    for city in data['cities']:
        list_item = xbmcgui.ListItem(label=city['name'])
        list_item.setArt({'icon': 'DefaultCity.png'})
        xbmcplugin.addDirectoryItem(
            handle=int(sys.argv[1]),
            url=f'plugin://{addon_id}/?action=city_stations&city={city["id"]}',
            listitem=list_item,
            isFolder=True
        )
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def show_all_stations():
    """Показать все станции"""
    data = load_radio_data()
    if not data:
        return
    
    stations = data.get('stations', [])
    show_stations_list(stations, "Все станции")

def show_country_stations(country):
    """Показать станции по стране"""
    data = load_radio_data()
    if not data:
        return
    
    country = urllib.parse.unquote(country)
    stations = [s for s in data.get('stations', []) if s.get('country_id') == int(country)]
    show_stations_list(stations, f"Страна: {country}")

def show_genre_stations(genre):
    """Показать станции по жанру"""
    data = load_radio_data()
    if not data:
        return
    
    genre = urllib.parse.unquote(genre)
    stations = []
    for station in data.get('stations', []):
        station_genres = station.get('genres_ids', [])
        if isinstance(station_genres, str):
            station_genres = [station_genres]
        
        if int(genre) in station_genres:
            stations.append(station)
    
    show_stations_list(stations, f"Жанр: {genre}")

def show_city_stations(city):
    """Показать станции по городу"""
    data = load_radio_data()
    if not data:
        return

    city = urllib.parse.unquote(city)
    stations = []
    for station in data.get('stations', []):
        station_cities = station.get('cities_ids', [])
        if isinstance(station_cities, str):
            station_cities = [station_cities]
        
        if int(city) in station_cities:
            stations.append(station)
    
    show_stations_list(stations, f"Город: {city}")


def show_stations_list(stations, title=""):
    """Показать список станций"""
    if not stations:
        xbmcgui.Dialog().ok(addon_name, 'Станции не найдены')
        return

    # Загружаем текущие ID моих станций для формирования контекстного меню
    fav_ids = set(str(x) for x in load_favorites())

    # Сортируем станции по названию
    stations.sort(key=lambda x: x.get('name', '').lower())

    for station in stations:
        name = station.get('name', 'Без названия')
        url = station.get('stream_original', '')
        icon = station.get('logo', '')
        descr = station.get('descr', '')
        station_id = str(station.get('id', name))

        list_item = xbmcgui.ListItem(label=name)
        if icon:
            list_item.setArt({'icon': icon, 'thumb': icon})

        tags = list_item.getMusicInfoTag()
        tags.setTitle(name)
        tags.setComment(descr)

        list_item.setProperty('IsPlayable', 'true')

        # Формирование контекстного меню для добавления/удаления
        context_menu = []
        if station_id in fav_ids:
            cmd = f"RunPlugin(plugin://{addon_id}/?action=remove_favorite&id={urllib.parse.quote(station_id)})"
            context_menu.append(('Удалить из Моих станций', cmd))
        else:
            cmd = f"RunPlugin(plugin://{addon_id}/?action=add_favorite&id={urllib.parse.quote(station_id)})"
            context_menu.append(('Добавить в Мои станции', cmd))

        list_item.addContextMenuItems(context_menu)

        xbmcplugin.addDirectoryItem(
            handle=int(sys.argv[1]),
            url=url,
            listitem=list_item,
            isFolder=False
        )

    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def input_search():
    """Только открывает клавиатуру и передает введенный запрос в каталог поиска"""
    dialog = xbmcgui.Dialog()
    query = dialog.input('Поиск радиостанции', type=xbmcgui.INPUT_ALPHANUM)
    
    # Если пользователь ввел слово и нажал Enter
    if query:
        search_url = f'plugin://{addon_id}/?action=search&query={urllib.parse.quote_plus(query)}'
        xbmc.executebuiltin(f'Container.Update({search_url})')


def show_search_results(query):
    """Строит каталог со списком найденных радиостанций"""
    data = load_radio_data()
    if not data:
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False)
        return

    query_lower = query.lower()
    stations = [
        s for s in data.get('stations', [])
        if query_lower in s.get('name', '').lower()
    ]

    if not stations:
        xbmcgui.Dialog().notification(addon_name, f'Ничего не найдено по: "{query}"', xbmcgui.NOTIFICATION_INFO, 3000)
        # Обязательно корректно закрываем пустой каталог, чтобы Kodi не зависал
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True)
        return

    show_stations_list(stations, f"Поиск: {query}")
    

def play_radio(url):
    """Воспроизведение радиостанции"""
    list_item = xbmcgui.ListItem(path=url)
    list_item.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, list_item)

def update_data():
    """Обновление данных с сервера"""
    progress_dialog = xbmcgui.DialogProgress()
    progress_dialog.create(addon_name, 'Обновление данных...')
    
    progress_dialog.update(0, 'Скачивание архива...')
    if download_and_extract_archive():
        # --- Очистка моих станций от удаленных из базы станций ---
        data = load_radio_data()
        if data and os.path.exists(FAVORITES_FILE_PATH):
            all_current_ids = {str(s.get('id', s.get('name', ''))) for s in data.get('stations', [])}
            favorites = load_favorites()
            # Оставляем только те ID, которые всё еще присутствуют в новой базе list.json:
            cleaned_favorites = [fav_id for fav_id in favorites if fav_id in all_current_ids]
            if len(cleaned_favorites) != len(favorites):
                save_favorites(cleaned_favorites)
        # -----------------------------------------------------
        progress_dialog.update(100, 'Данные успешно обновлены!')
        xbmc.sleep(1000)
        xbmcgui.Dialog().notification(
            addon_name,
            'Данные успешно обновлены',
            xbmcgui.NOTIFICATION_INFO,
            3000
        )
    else:
        progress_dialog.update(100, 'Ошибка при обновлении данных')
        xbmc.sleep(1000)

    progress_dialog.close()
    
    # Обновляем список
    xbmc.executebuiltin('Container.Refresh()')

def clear_cache():
    """Очистка кэша"""
    try:
        # Удаляем JSON файл
        if os.path.exists(JSON_FILE_PATH):
            os.remove(JSON_FILE_PATH)
            log("Кэш очищен")
            xbmcgui.Dialog().notification(
                addon_name,
                'Кэш очищен',
                xbmcgui.NOTIFICATION_INFO,
                3000
            )
        else:
            xbmcgui.Dialog().notification(
                addon_name,
                'Кэш уже пуст',
                xbmcgui.NOTIFICATION_INFO,
                3000
            )
    except Exception as e:
        log(f"Ошибка при очистке кэша: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification(
            addon_name,
            'Ошибка при очистке кэша',
            xbmcgui.NOTIFICATION_ERROR,
            3000
        )


def load_favorites():
    """Загрузка списка идентификаторов моих станций"""
    if os.path.exists(FAVORITES_FILE_PATH):
        try:
            with open(FAVORITES_FILE_PATH, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            log(f"Ошибка при чтении моих станций: {str(e)}", xbmc.LOGERROR)
    return []


def save_favorites(favorites):
    """Сохранение списка моих станций в файл"""
    try:
        with open(FAVORITES_FILE_PATH, 'w', encoding='utf-8') as f:
            json.dump(favorites, f, ensure_ascii=False, indent=2)
    except Exception as e:
        log(f"Ошибка при сохранении Моих станций: {str(e)}", xbmc.LOGERROR)


def add_to_favorites(station_id):
    """Добавление радиостанции в мои станции"""
    favorites = load_favorites()
    if station_id not in favorites:
        favorites.append(station_id)
        save_favorites(favorites)
        xbmcgui.Dialog().notification(addon_name, 'Добавлено в Мои станции', xbmcgui.NOTIFICATION_INFO, 2000)
        # Обновляем только если пользователь находится внутри моих станций
        if 'action=favorites' in xbmc.getInfoLabel('Container.FolderPath'):
            xbmc.executebuiltin('Container.Refresh()')


def remove_from_favorites(station_id):
    """Удаление радиостанции из моих станций"""
    favorites = load_favorites()
    if station_id in favorites:
        favorites.remove(station_id)
        save_favorites(favorites)
        xbmcgui.Dialog().notification(addon_name, 'Удалено из Моих станций', xbmcgui.NOTIFICATION_INFO, 2000)

        # Проверяем, находимся ли мы прямо сейчас внутри папки «Мои станции»
        if 'action=favorites' in xbmc.getInfoLabel('Container.FolderPath'):
            if not favorites:
                # Если удалили последний элемент — переходим в главное меню плагина
                xbmc.executebuiltin(f'Container.Update(plugin://{addon_id}/)')
            else:
                # Если в моих станциях еще остались станции — просто обновляем список
                xbmc.executebuiltin('Container.Refresh()')            


def show_favorites():
    """Отображение раздела со списком моих станций"""
    data = load_radio_data()
    if not data:
        return
    fav_ids = set(str(x) for x in load_favorites())
    stations = [s for s in data.get('stations', []) if str(s.get('id', s.get('name', ''))) in fav_ids]

    if not stations:
        xbmcgui.Dialog().notification(addon_name, 'В Моих станциях пока ничего нет', xbmcgui.NOTIFICATION_INFO, 2500)
        # Перенаправляем пользователя обратно в корень плагина
        xbmc.executebuiltin(f'Container.Update(plugin://{addon_id}/)')
        return

    show_stations_list(stations, "Мои станции")


def router(paramstring):
    """Маршрутизатор команд"""
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get('action', '')
    country = params.get('country', '')
    genre = params.get('genre', '')
    city = params.get('city', '')
    station_id = params.get('id', '')
    query = params.get('query', '')
    url = params.get('url', '')

    if action == 'update':
        update_data()
    elif action == 'clear_cache':
        clear_cache()
    elif action == 'favorites':
        show_favorites()
    elif action == 'add_favorite' and station_id:
        add_to_favorites(urllib.parse.unquote(station_id))
    elif action == 'remove_favorite' and station_id:
        remove_from_favorites(urllib.parse.unquote(station_id))
    elif action == 'countries':
        show_countries()
    elif action == 'genres':
        show_genres()
    elif action == 'cities':
        show_cities()
    elif action == 'all_stations':
        show_all_stations()
    elif action == 'country_stations' and country:
        show_country_stations(country)
    elif action == 'genre_stations' and genre:
        show_genre_stations(genre)
    elif action == 'city_stations' and city:
        show_city_stations(city)
    elif action == 'input_search':
        input_search()
    elif action == 'search' and query:
        show_search_results(query)
    elif url:
        play_radio(url)
    else:
        show_main_menu()        


if __name__ == '__main__':
    router(sys.argv[2][1:])
    