# -*- coding: utf-8 -*-

from sys import argv
import requests
import random
import string
import json
import os

import xbmcgui
import xbmcaddon
import xbmcplugin
from xbmcvfs import translatePath
from urllib.parse import parse_qs, urlencode
from afisha import afisha_api
from providers import get_video_urls,decode64,find_episode_videos

ADDON_NAME =   'plugin.video.afisha'
ADDON      =   xbmcaddon.Addon(id=ADDON_NAME)
URL = argv[0]
HANDLE = int(argv[1])


# Получение пути к директории данных плагина
addon_data_dir = translatePath(ADDON.getAddonInfo('profile'))
if not os.path.exists(addon_data_dir):
    os.makedirs(addon_data_dir)


# Get sort from plugin settings
addon = xbmcaddon.Addon()
sort_setting = addon.getSetting('sort')
items_on_page = int(addon.getSetting('items_on_page'))
sort_dict = {'По популярности': 'Popular', 'По рейтингу': 'Rating', 'По дате': 'Date'}
sorting = sort_dict[sort_setting]


def get_seasons_info(kp_id,season_id=False):
    headers = {'x-api-key': decode64('MmJmM2QxYzQtYzQ0OS00NzVmLTg2NGUtOTU5MDkyOGQxYTZl')}
    seasons = requests.get(f'https://kinopoiskapiunofficial.tech/api/v2.2/films/{kp_id}/seasons', params=params, headers=headers).json()['items']
    return seasons if not season_id else seasons[int(season_id)-1]['episodes']


def get_krasview_auth():
    token_file = os.path.join(addon_data_dir, 'krasview.json')
    if not os.path.exists(token_file):
        prov = requests.Session()
        prov_url = decode64('aHR0cHM6Ly9hdG90by5ydS9hcGk=')
        random_string = ''.join(random.choices(string.ascii_letters + string.digits, k=12))
        json_data = {'email': f'{random_string}@mail.ru','password': random_string,}
        body = prov.post(f'{prov_url}/register/', json=json_data).json()
        if 'success' in body.keys():
            token = body["token"]
            json_data['token'] = token
            cookies_dict = requests.utils.dict_from_cookiejar(prov.cookies)
            auth = {'auth': json_data, 'cookies': cookies_dict}
            with open(token_file, 'w') as file:
                json.dump(auth, file)
    else:
        with open(token_file, 'r') as file:
            auth = json.load(file)
    return auth




def image_orig_size(url):
    if not url is None:
        return 'https://'+url.split('q85i/')[1]
    else:
        return url


def get_params():
    param_string = argv[2][1:]
    return dict(parse_qs(param_string))


def main_menu():
    menu_items = [
        ("Поиск", {"action": "search"}),
        ("Фильмы", {"action": "movies"}),
        ("Сериалы", {"action": "series"}),
        ("Выбор Афиши", {"action": "afisha_select"}),
        ("Изменившие мир", {"action": "changed_world"}),
        ("Жанры", {"action": "genre"}),
        ("Страны", {"action": "country"}),
    ]
    for title, params in menu_items:
        list_item = xbmcgui.ListItem(label=title)
        url_with_params = f"{URL}?{urlencode(params)}"
        xbmcplugin.addDirectoryItem(HANDLE, url=url_with_params, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def show_video_info(category, items,pages=False, action=None):
    xbmcplugin.setPluginCategory(HANDLE, category)
    xbmcplugin.setContent(HANDLE, 'movies')
    for item in items:
        if item['productionYear'] is None:
            continue
        list_item = xbmcgui.ListItem(item['name'])
        url_with_params = f"{URL}?action={item['id']}&movie_name={item['name']}&movie_year={item['productionYear'][:4]}"
        list_item.setContentLookup(False)
        if item['image']:
            fanart = item['image']['url']
        else:
            fanart = None
        if item['media']['posters']:
            poster = item['media']['posters'][0]['image']['url']
        else:
            poster = None
        list_item.setArt({'fanart': image_orig_size(fanart), 'poster': image_orig_size(poster), 'thumb': image_orig_size(poster)})
        video_info = {
            'genre': [x['name'] for x in item['genres']],
            'country': [x['name'] for x in item['productionCountries']],
            'year': item['productionYear'],
            'rating': item['rating'],
            'plotoutline': item['verdict'],
            'plot': item['description'],
        }
        context_menu_items = [
            ('Показать фото', f'Container.Update({URL}?action=context_images&media_id={item["id"]})'),
            ('Смотреть трейлер', f'Container.Update({URL}?action=context_trailers&media_id={item["id"]})'),
            ('Показать актеров', f'Container.Update({URL}?action=context_actors&media_id={item["id"]})'),
            ('Почитать отзывы', f'Container.Update({URL}?action=context_reviews&media_id={item["id"]})'),
            ('Найти похожие', f'Container.Update("{URL}?action=context_similar&media_id={item["id"]}")'),
        ]

        list_item.addContextMenuItems(context_menu_items)
        list_item.setInfo('video', video_info)
        xbmcplugin.addDirectoryItem(HANDLE, url=url_with_params, listitem=list_item, isFolder=True)
    if (pages and pages['hasNextPage']): 
        list_item = xbmcgui.ListItem('Следующая страница...')
        url_with_params = f"{URL}?action={action}&cursor={pages['endCursor']}"
        xbmcplugin.addDirectoryItem(HANDLE, url=url_with_params, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def show_reviews(reviews):
    if reviews:
        all_text = "\n".join([f"===============\n({x['authorRating']}) {x['author']['name']}:\n------------\n{x['text']}" for x in reviews])
        xbmcgui.Dialog().textviewer('Отзывы', all_text)
    else:
        xbmcgui.Dialog().notification('Отзывы', 'Отзывов от пользователей не найдено.', xbmcgui.NOTIFICATION_INFO, 3000)


def show_actors(items):
    xbmcplugin.setPluginCategory(HANDLE, 'Actors')
    xbmcplugin.setContent(HANDLE, 'movies')
    for item in items:
        list_item = xbmcgui.ListItem(item['name'])
        url_with_params = f"{URL}?action={item['id']}"
        list_item.setContentLookup(False)
        if item['image']:
            actor_photo = item['image']['url']
        else:
            actor_photo = None
        list_item.setArt({'fanart': image_orig_size(actor_photo), 'poster': image_orig_size(actor_photo), 'thumb': image_orig_size(actor_photo)})
        xbmcplugin.addDirectoryItem(HANDLE, url=url_with_params, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def show_trailers(items):
    if items:
        xbmcplugin.setPluginCategory(HANDLE, 'Trailers')
        xbmcplugin.setContent(HANDLE, 'movies')
        for item in items:
            list_item = xbmcgui.ListItem(item['name'])
            list_item.setContentLookup(False)
            if item['galleryPreviewImage']:
                trailer_photo = item['galleryPreviewImage']['url']
            else:
                trailer_photo = None
            list_item.setArt({'fanart': image_orig_size(trailer_photo), 'poster': image_orig_size(trailer_photo), 'thumb': image_orig_size(trailer_photo)})
            xbmcplugin.addDirectoryItem(HANDLE, item['m3u8Url'], list_item)
        xbmcplugin.endOfDirectory(HANDLE)
    else:
        xbmcgui.Dialog().notification('Трейлеры', 'Трейлеров не найдено.', xbmcgui.NOTIFICATION_INFO, 3000)
    

def list_seasons(seasons,kp_id):
    xbmcplugin.setPluginCategory(HANDLE, 'Seasons')
    xbmcplugin.setContent(HANDLE, 'movies')
    for season in seasons:
        list_item = xbmcgui.ListItem(f'{season["number"]}й сезон')
        url_with_params = f"{URL}?action=season_{season['number']}&kp_id={kp_id}&movie_name={movie_name}&movie_year={movie_year}"
        list_item.setContentLookup(False)
        xbmcplugin.addDirectoryItem(HANDLE, url=url_with_params, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)    


def list_episodes(kp_id,season_id):
    episodes = get_seasons_info(kp_id,season_id)
    xbmcplugin.setPluginCategory(HANDLE, 'Episodes')
    xbmcplugin.setContent(HANDLE, 'movies')
    for x in episodes:
        list_item = xbmcgui.ListItem(f'S{x["seasonNumber"]}E{x["episodeNumber"]}: {x["nameRu"]}')
        url_with_params = f"{URL}?action=episode_{x['episodeNumber']}&season_id={x['seasonNumber']}&kp_id={kp_id}&movie_name={movie_name}&movie_year={movie_year}"
        list_item.setContentLookup(False)
        video_info = {'plot': x['synopsis']}
        list_item.setInfo('video', video_info)
        xbmcplugin.addDirectoryItem(HANDLE, url=url_with_params, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)    


def show_video_urls(movie_name, movie_year,episode_videos=None):
    items = episode_videos if not episode_videos is None else get_video_urls(movie_name, movie_year) 
    if isinstance(items, int):
        seasons = get_seasons_info(items)
        list_seasons(seasons,items)
    elif items:
        xbmcplugin.setPluginCategory(HANDLE, 'Movie urls')
        xbmcplugin.setContent(HANDLE, 'videos')
        for item in items:
            list_item = xbmcgui.ListItem(item[0])
            list_item.setContentLookup(False)
            if item[2]=='mpd':
                list_item.setMimeType('application/dash+xml')
                list_item.setProperty('inputstream', 'inputstream.adaptive')
            xbmcplugin.addDirectoryItem(HANDLE, item[1], list_item)
        xbmcplugin.endOfDirectory(HANDLE, updateListing=False)
    else:
        xbmcgui.Dialog().notification('Видео', 'Источники с видео не найдены.', xbmcgui.NOTIFICATION_INFO, 3000)


def show_genres_countries(filter_type,items):
    xbmcplugin.setPluginCategory(HANDLE, filter_type.capitalize())
    content_type = {'country':'countries','genre':'genres'}
    xbmcplugin.setContent(HANDLE, content_type[filter_type])
    for item in items:
        list_item = xbmcgui.ListItem(item['title'])
        url_with_params = f"{URL}?action={filter_type}___{item['value']}"
        list_item.setContentLookup(False)
        xbmcplugin.addDirectoryItem(HANDLE, url=url_with_params, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)


def show_images(items):
    xbmcplugin.setPluginCategory(HANDLE, 'Images')
    xbmcplugin.setContent(HANDLE, 'images')
    for item_id,item in enumerate(items,1):
        list_item = xbmcgui.ListItem(f"{item_id}")
        #list_item.setContentLookup(False)
        if item['fullImage']:
            full_image = item['fullImage']['originalUrl']
        else:
            full_image = None
        list_item.setArt({'fanart': full_image, 'poster': full_image, 'thumb': full_image})
        #list_item.setInfo(type='image', infoLabels={'Title': f"{item_id}"})
        xbmcplugin.addDirectoryItem(HANDLE, url=full_image, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)


def search():
    movie_name = xbmcgui.Dialog().input("Введите запрос для поиска")
    if not movie_name:
        return
    movies = afisha.search_films(movie_name)
    if movies:
        show_video_info('Search', movies['items'], movies['pageInfo'])
    else:
        xbmcgui.Dialog().notification('Поиск', f'По запросу "{movie_name}" ничего не найдено.', xbmcgui.NOTIFICATION_INFO, 3000)


afisha = afisha_api(sorting,items_on_page)
kv_auth = get_krasview_auth()


if __name__ == '__main__':
    params = get_params()
    action = params.get('action', [None])[0]
    cursor = params.get('cursor', [''])[0]
    media_id = params.get('media_id',[''])[0]
    movie_name = params.get('movie_name',[''])[0]
    movie_year = params.get('movie_year',[''])[0]
    season_id = params.get('season_id',[''])[0]
    kp_id = params.get('kp_id',[''])[0]

    if action == 'search':
        search()
    elif action == 'movies':
        movies = afisha.search_films(movie_type='movies', cursor=cursor)
        show_video_info('Movies', movies['items'], movies['pageInfo'], action)
    elif action == 'series':
        series = afisha.search_films(movie_type='tvshows', cursor=cursor)
        show_video_info('Series', series['items'], series['pageInfo'], action)
    elif action == 'afisha_select':
        movies = afisha.search_films(afisha_choice=True, cursor=cursor)
        show_video_info('Afisha_Choice', movies['items'], movies['pageInfo'], action)
    elif action == 'changed_world':
        movies = afisha.search_films(changed_world=True, cursor=cursor)
        show_video_info('Changed_World', movies['items'], movies['pageInfo'], action)
    elif action in ('genre','country'):
        filters = afisha.search_films(genre_country=action, cursor=cursor)[0]
        show_genres_countries(action,filters)
    elif not action is None:
        if action.startswith('context'):
            context_type = action.split('_')[1]
            media_info = afisha.media_info(media_id)
            if context_type == 'similar':
                show_video_info('Similar', media_info['similar'])
            elif context_type == 'reviews':
                show_reviews(media_info['reviews']['userReviews']['items'])
            elif context_type == 'actors':
                show_actors(media_info['members']['actors'])
            elif context_type == 'trailers':
                show_trailers(media_info['media']['trailers']+media_info['media']['videos'])
            elif context_type == 'images':
                show_images(media_info['media']['photos']+media_info['media']['posters'])
        elif action.startswith('Movie'):
            show_video_urls(movie_name, movie_year)
        elif action.startswith('Person'):
            person_info = afisha.person_info(action)
            show_video_info('Actor_movies', person_info['roles']['movie']['actor'])
        elif action.startswith('genre') or action.startswith('country'):
            filter_type,filter_value = action.split('___')
            if filter_type == 'genre':
                movies = afisha.search_films(genre=filter_value, cursor=cursor)
            else:
                movies = afisha.search_films(country=filter_value, cursor=cursor)
            show_video_info('Movies', movies['items'], movies['pageInfo'], action)
        elif action.startswith('season'):
            list_episodes(kp_id,action.split('_')[1])
        elif action.startswith('episode'):
            episode_videos = find_episode_videos(kp_id,season_id,action.split('_')[1],movie_name, movie_year)
            show_video_urls(movie_name, movie_year,episode_videos)
            #list_episodes(action.split('_')[1])
    else:
        main_menu()

