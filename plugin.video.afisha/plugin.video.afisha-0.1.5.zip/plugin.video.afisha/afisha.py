import requests


class afisha_api():
    def __init__(self, sorting, items_on_page):
        self.url = 'https://graph.afisha.ru/graphql'
        self.sorting = sorting
        self.items_on_page = items_on_page

    def search_films(self,search='',cursor = '', movie_type='all',afisha_choice=None,changed_world=None,genre_country=None,genre=None,country=None):
        if not afisha_choice is None:
            query_request = f'sort={self.sorting}&movieType=all&afishaChoice={afisha_choice}'
        elif not changed_world is None:
            query_request = f'sort={self.sorting}&movieType=all&separated=changed_world'
        elif not genre is None:
            query_request = f'sort={self.sorting}&movieType=all&genre={genre}'
        elif not country is None:
            query_request = f'sort={self.sorting}&movieType=all&country={country}'
        else:
            query_request = f'searchText={search}&sort={self.sorting}&movieType={movie_type}'
        json_data = {
            'operationName': 'MovieCatalog',
            'variables': {
                'count': self.items_on_page,
                'cursor': cursor,
                'query': query_request,
                'tileImageWidth': 242,
                'tileImageHeight': 161,
                'posterImageWidth': 161,
                'posterImageHeight': 242,
            },
            'extensions': {
                'persistedQuery': {
                    'version': 1,
                    'sha256Hash': '24d5492c476fba29dd91f93da0dc31c97d941e92f814f857275851f2fd323706',
                },
            },
        }
        response = requests.post(self.url, json=json_data).json()
        if genre_country is None:
            return response['data']['movieCatalog']
        else:
            return [x['items'] for x in response['data']['movieCatalog']['filters'] if x['name']==genre_country]

    def media_info(self, media_id):
        json_data = {
            'operationName': 'MovieQuery',
            'variables': {
                'id': media_id,
                'personImageWidth': 130,
                'userImageWidth': 78,
                'headerImageWidth': 487,
                'headerImageHeight': 325,
                'galleryPreviewImageHeight': 135,
                'galleryMiniImageHeight': 135,
                'afishaDailyImageWidth': 385,
                'afishaDailyImageHeight': 216,
                'reviewsCount': 20,
                'scheduleCount': 2,
                'recentAfishaDailyType': 'CINEMA',
                'marketingBannerHeight': 133,
                'tileImageWidth': 438,
                'tileImageHeight': 438,
                'posterImageWidth': 161,
                'posterImageHeight': 242,
                'cityId': 'City_2599',
            },
            'extensions': {
                'persistedQuery': {
                    'version': 1,
                    'sha256Hash': 'ceb118e180b64fc95fa8a00273987b691786e17827788f349d40b0d46392e28c',
                },
            },
        }
        response = requests.post(self.url, json=json_data).json()
        return response['data']['movie']

    def person_info(self, person_id):
        json_data = {
            'operationName': 'PersonQuery',
            'variables': {
                'id': person_id,
                'headerImageWidth': 487,
                'headerImageHeight': 325,
                'tileImageWidth': 325,
                'tileImageHeight': 216,
                'posterImageWidth': 161,
                'posterImageHeight': 242,
                'articleImageWidth': 385,
                'articleImageHeight': 385,
                'galleryPreviewImageHeight': 315,
                'galleryMiniImageHeight': 135,
            },
            'extensions': {
                'persistedQuery': {
                    'version': 1,
                    'sha256Hash': '07b886cb12124303018d6cb8e8fc87fc845aa8524cef1e2c5818d96903299384',
                },
            },
        }
        response = requests.post(self.url, json=json_data).json()
        return response['data']['person']
