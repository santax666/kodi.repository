# -*- coding: utf-8 -*-

import re
import json
import base64
import string
import random
import requests
import urllib.parse



def decode64(hash_str):
    return base64.b64decode(hash_str.encode('utf-8')+b'==').decode('utf-8')


def get_kinopoisk_id(movie_name,movie_year):
    items = requests.get(f'https://android1.mzona.net/api/v1/search/{movie_name}').json()['items']
    movies = [(x['id'],x['serial']) for x in items if str(x['year'])==movie_year]
    kp_id = movies[0][0] if movies else False
    kp_serial = movies[0][1] if movies else False
    return kp_id,kp_serial
#    headers = {'x-api-key': decode64('MmJmM2QxYzQtYzQ0OS00NzVmLTg2NGUtOTU5MDkyOGQxYTZl')}
#    params = {'yearFrom':movie_year,'yearTo':movie_year,'keyword':movie_name}
#    body = requests.get('https://kinopoiskapiunofficial.tech/api/v2.2/films', params=params, headers=headers).json()
#    return body['items'][0]['kinopoiskId'] if body['total']>0 else False


def prov_8(kp_id, season_id='null',episode_id='null'):
    finded_videos = []
    prov = requests.Session()
    headers = {
    'referer': 'https://kinobadi2.top/',
    'origin': 'https://wonder-as.allarknow.online',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36',
    }
    prov.headers.update(headers)
    token = decode64('MjM4NzJlNDQ0MzcyMmQ2NTc4ZmQ2ZmQ4NjAwYzEx')
    url1 = f'https://api.apbugall.org/?token={token}&kp={kp_id}'
    body = prov.get(url1).json()
    if body['status']!='success':
        return finded_videos
    url2 = body['data']['iframe']
    url3 = url2.split("/?")[0]
    body = prov.get(url2).text
    ac = re.search('meta name=\"user\" content=\"(.*?)\"',body).group(1)
    headers['accepts-controls'] = ac
    prov.headers.update(headers)
    pattern = f'\"id_file\":\"(\d*)\",\"top_bought\":null,\"seasons\":{season_id},\"episode\":{episode_id},'
    files_info = set(re.findall(pattern,body))
    for file_id in files_info: 
        videos = prov.post(f'{url3}/movie/{file_id}', data={'token':token,'av1':'true','autoplay':'0'}, timeout=3).json()
        for video in videos['hlsSource']:
            for qt in ('360','480','720'):
                video['quality'].pop(qt,'')
            for qt,urls in video['quality'].items():
                for unique_url in set(urls.split(' or ')):
                    video_url = unique_url + '|' + '&'.join([f'{key}={value}' for key, value in headers.items()])
                    finded_videos.append((f"(HLS): [{qt}] {video['label']}",video_url,'hls'))
    return finded_videos
    

def prov_7(kp_id,season_id=False,episode_id=False):
    finded_videos = []
    url = f"http://hd.kp-ppc.xyz/iplayer/pl.php?kp={kp_id}"
    base64_body = requests.get(url, headers={'Referer': "ya.ru"}).text
    if base64_body == 'video_not_found':
        return finded_videos
    items = json.loads(decode64(base64_body).replace('},]','}]'))['playlist']
    if season_id and episode_id:
        try:
            items = items[int(season_id)-1]['folder'][int(episode_id)-1]['folder']
        except:
            return finded_videos
    for item in items:
        title = item.get('title',False) or item.get('comment',False)
        video_url = item['file'].split(']')[-1]
        video_ext = video_url.split('.')[-1]
        finded_videos.append((f'({video_ext.upper()}): {title}',video_url,video_ext))
    return finded_videos


def prov_6(kp_id,season_id=False,episode_id=False):
    finded_videos = []
    prov = requests.Session()
    url = decode64('aHR0cHM6Ly9hcGkubW92aWVsYWIuZ3VydS9hcGkvdjEvbW92aWVzLw==')
    headers = json.loads(decode64('eyJ1c2VyLWFnZW50IjoiRGFydC8zLjUgKGRhcnQ6aW8pIiwicGxhdGZvcm0iOiJtb2JpbGUifQ=='))
    prov.headers.update(headers)
    body = prov.get(f'{url}{kp_id}').json()
    if not body.get('result',False):
        return []
    if season_id and episode_id:
        videos_info =body['result']['serial_episodes'][season_id]['episodes'][episode_id]['translations']
        items = [(x['name'],x['hash']) for x in videos_info.values()]
    else:
        items = [(body['result']['player']['translator'],body['result']['player']['token'])]
    for item in items:
        title,hash = item
        json_data = json.loads(decode64('eyJ0b2tlbiI6IjVjNzhhMGUwZTliYWEwMjM5YTYwYWQ1ZDRiMDBhNGI2Iiwia2V5IjoiZDYyMjQ2MTQzYzU3YTI3ZjFjMWZlNWU5YmJiODdkY2IifQ=='))
        params = json_data.copy()
        params['hash'] = hash
        params['s'] = int(season_id)
        params['e'] = int(episode_id)
        params['method'] = 'getkey'
        url = decode64('aHR0cHM6Ly9hcGl2Yi5jb20vYXBpL3BsYXlsaXN0Lmpzb24=')
        #url = decode64('aHR0cHM6Ly9hcGl2Yi5jb20vYXBpX3N5c3RlbS9nZXRmaWxlLnBocA==')
        body = prov.get(url, params=params).json()
        key = body['key']
        params = json_data.copy()
        params['hash'] = hash
        params['s'] = int(season_id)
        params['e'] = int(episode_id)
        params['key2'] = key
        video_url = prov.get(url, params=params).json()['url'] + '|' + '&'.join([f'{key}={value}' for key, value in headers.items()])
        finded_videos.append((f'(HLS): {title}',video_url,'hls'))
    return finded_videos


def prov_4(movie_name,movie_year,season_id=False,episode_id=False):
    from addon import kv_auth
    finded_videos = []
    prov = requests.Session()
    prov_url = decode64('aHR0cHM6Ly9hdG90by5ydS9hcGk=')
    prov.headers.update({'cookie': f'token={kv_auth["auth"]["token"]}','User-Agent':'App.krasview+1/1.1.68'})
    prov.cookies = requests.utils.cookiejar_from_dict(kv_auth['cookies'])
    json_data = {'page':'1','section':['movie','series'],'query':f'{movie_name} {movie_year}'}
    movies = prov.post(f'{prov_url}/channel/list', json=json_data).json()['data']
    if not movies:
        return finded_videos
    movies.sort(key=lambda x: x['id'])
    movie_page = movies[0]['address']
    body = prov.get(f'{prov_url}/channel/item/{movie_page}').json()
    if body['movie'] is None:
        seasons = [x for x in body['seasons'] if bool(re.search('(\d+)',x['title']))]
        season = [x['id'] for x in seasons if re.search('(\d+)',x['title'])[0]==season_id][0]
        video_id = prov.get(f'{prov_url}/channel/season/{season}').json()['video'][int(episode_id)-1]['v_id']
        movie_info = prov.get(f'{prov_url}/video/{video_id}').json()['video']
    else:
        movie_info = body['movie']
    video_title = movie_info['v_title'].replace('&quot;','"')
    audio_count = movie_info['audio']
    finded_videos.append((f'(MP4): {video_title} [озвучек - {audio_count}]',movie_info['url2'],'mp4'))
    finded_videos.append((f'(MPD): {video_title} [озвучек - {audio_count}]',movie_info['url1'],'mpd'))
    return finded_videos


def prov_3(kp_id,season_id=False,episode_id=False):
    finded_videos = []
    response = requests.get(f'https://player.cdnvideohub.com/playerjs?partner=1&kid={kp_id}')
    if response.status_code==200:
        json_str = re.search("file: (.*)}\);",response.text,re.S).group(1)
        json_str = json_str.replace(' ','').replace('\n','').replace(',}','}').replace(',]',']').replace("'",'"')[:-1]
        videos = json.loads(json_str)
        if season_id and episode_id:
            urls = [x['file'] for x in videos[int(season_id)-1]['folder'] if re.search('\d+',x['title'])[0]==episode_id]
        else:
            urls = [x['file'] for x in videos[0]['folder']]
        for url_ind,url_str in enumerate(urls,1):
            finded_videos.append((f'(HLS): вариант №{url_ind}',url_str,'hls'))
    return finded_videos 

 
def prov_2(kp_id):
    finded_videos = []
    body = requests.get(f'https://api.ninsel.ws/embed/kp/{kp_id}').text
    film_search = re.search(r'title: "(.*)"',body)
    if not film_search is None:
        film_name = film_search.group(1)
        audio_count = len(json.loads(re.search(r'audio: ({.*})',body).group(1))['names'])
        dash_search = re.search(r'dash: "(.*)"',body)
        if not dash_search is None:
            dash_url = dash_search.group(1)
            finded_videos.append((f'Collaps (MPD): {film_name} ({audio_count} озвучек)',dash_url,'mpd'))
        hls_search = re.search(r'hls: "(.*)"',body)
        if not hls_search is None:
            hls_url = hls_search.group(1)
        finded_videos.append((f'Collaps (HLS): {film_name} ({audio_count} озвучек)',hls_url,'hls'))
    return finded_videos


def prov_1(kp_id,season_id=False,episode_id=False):
    finded_videos = []
    api_url = decode64('aHR0cHM6Ly9hcGkubHVtZXguc2l0ZQ==')
    prov = requests.Session()
    json_data = json.loads(decode64('eyJ1c2VybmFtZSI6ICJsbWRfaW50IiwgInBhc3N3b3JkIjogIkg5TjNjSlQxNGM1NCJ9'))
    body = prov.post(f'{api_url}/login', json=json_data).json()
    access_token = body['accessToken']
    refresh_token = body['refreshToken']
    access_token = prov.post(f'{api_url}/refresh', json={'token': refresh_token}).json()['accessToken']
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0',
        'authorization': f'Bearer {access_token}',
    }
    prov.headers.update(headers)
    params = {
        'clientId': decode64('VW9xYWkxSFROQlpD'),
        'kpId': kp_id,
        'domain': 'lmd',
        'contentType': 'short',
    }
    videos_info = prov.get(f'{api_url}/stream', params=params)
    if videos_info.status_code != 200:
        return finded_videos
    else:
        items = videos_info.json()['player']['media']
        if (season_id and episode_id):
            try:
                items = items[int(season_id)-1]['episodes'][int(episode_id)-1]['media']
            except:
                return finded_videos
    for video in items:
        video_info = prov.post(f'{api_url}{video["playlist"]}')
        if video_info.status_code==200:
            finded_videos.append((f"(HLS): {video.get('translation_name','')}",'http:'+video_info.json()['url'],'hls'))
    return finded_videos        


def get_video_urls(movie_name,movie_year):
    from xbmcgui import DialogProgress
    result = []
    progress = DialogProgress()
    progress.create("Выполняется поиск", "Пожалуйста, подождите...")
    kp_id,kp_serial = get_kinopoisk_id(movie_name,movie_year)
    if not kp_id:
        return None
    elif kp_serial:
        return kp_id
    else:
        provs_with_args = [
            (prov_8, (kp_id,),'Alloha'),
            (prov_7, (kp_id,),'HDVideoBox'),
            (prov_1, (kp_id,),'VideoCDN'), # слишком долго для серий, оптимизировать в будущем
            (prov_3, (kp_id,),'Videohub'), # не используется для сериалов..
            (prov_4, (movie_name, movie_year),'Krasview'),
            (prov_6, (kp_id,),'HDVB')
        ]
        for ind,provs in enumerate(provs_with_args):
            func, args, prov_name = provs
            if progress.iscanceled():
                break
            percent = int((ind/len(provs_with_args))*100)
            progress.update(percent, f"Поиск в {prov_name}")
            videos = [(f'{prov_name} {x[0]}',x[1],x[2]) for x in func(*args)]
            result.extend(videos)
    progress.close()
    return result


def find_episode_videos(kp_id,season_id,episode_id,movie_name,movie_year):
    import xbmc
    from xbmcgui import DialogProgress
    result = []
    progress = DialogProgress()
    progress.create("Выполняется поиск", "Пожалуйста, подождите...")
    provs_with_args = [
        (prov_8, (kp_id,season_id,episode_id,),'Alloha'),
        (prov_7, (kp_id,season_id,episode_id,),'HDVideoBox'),
        (prov_1, (kp_id,season_id,episode_id,),'VideoCDN'),
        (prov_3, (kp_id,season_id,episode_id,),'Videohub'),
        (prov_4, (movie_name, movie_year,season_id,episode_id,),'Krasview'),
        (prov_6, (kp_id,season_id,episode_id,),'HDVB')
    ]
    for ind,provs in enumerate(provs_with_args):
        func, args, prov_name = provs
        if progress.iscanceled():
            break
        percent = int((ind/len(provs_with_args))*100)
        progress.update(percent, f"Поиск в {prov_name}")
        videos = [(f'{prov_name} {x[0]}',x[1],x[2]) for x in func(*args)]
        result.extend(videos)
    progress.close()
    return result
    
    
