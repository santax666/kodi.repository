# -*- coding: utf-8 -*-

import re
import json
import base64
import string
import random
import requests
import urllib.parse



def decode64(hash_str):
    return base64.b64decode(hash_str.encode('utf-8')+b'==').decode('utf-8')


def get_kinopoisk_id(movie_name,movie_year):
    items = requests.get(f'https://android1.mzona.net/api/v1/search/{movie_name}').json()['items']
    movies = [(x['id'],x['serial']) for x in items if str(x['year'])==movie_year]
    kp_id = movies[0][0] if movies else False
    kp_serial = movies[0][1] if movies else False
    return kp_id,kp_serial
#    headers = {'x-api-key': decode64('MmJmM2QxYzQtYzQ0OS00NzVmLTg2NGUtOTU5MDkyOGQxYTZl')}
#    params = {'yearFrom':movie_year,'yearTo':movie_year,'keyword':movie_name}
#    body = requests.get('https://kinopoiskapiunofficial.tech/api/v2.2/films', params=params, headers=headers).json()
#    return body['items'][0]['kinopoiskId'] if body['total']>0 else False


def prov_8(kp_id, season_id='null',episode_id='null'):
    finded_videos = []
    prov = requests.Session()
    headers = {
    'referer': 'https://kinobadi2.top/',
    'origin': 'https://wonder-as.allarknow.online',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36',
    }
    prov.headers.update(headers)
    token = decode64('MjM4NzJlNDQ0MzcyMmQ2NTc4ZmQ2ZmQ4NjAwYzEx')
    url1 = f'https://api.apbugall.org/?token={token}&kp={kp_id}'
    body = prov.get(url1).json()
    if body['status']!='success':
        return finded_videos
    url2 = body['data']['iframe']
    url3 = url2.split("/?")[0]
    body = prov.get(url2).text
    ac = re.search('meta name=\"user\" content=\"(.*?)\"',body).group(1)
    headers['accepts-controls'] = ac
    prov.headers.update(headers)
    pattern = f'\"id_file\":\"(\d*)\",\"top_bought\":null,\"seasons\":{season_id},\"episode\":{episode_id},'
    files_info = set(re.findall(pattern,body))
    for file_id in files_info: 
        videos = prov.post(f'{url3}/movie/{file_id}', data={'token':token,'av1':'true','autoplay':'0'}, timeout=3).json()
        for video in videos['hlsSource']:
            for qt in ('360','480','720'):
                video['quality'].pop(qt,'')
            for qt,urls in video['quality'].items():
                for unique_url in set(urls.split(' or ')):
                    video_url = unique_url + '|' + '&'.join([f'{key}={value}' for key, value in headers.items()])
                    finded_videos.append((f"(HLS): [{qt}] {video['label']}",video_url,'hls'))
    return finded_videos
    

def prov_7(kp_id,season_id=False,episode_id=False):
    finded_videos = []
    url = f"http://hd.kp-ppc.xyz/iplayer/pl.php?kp={kp_id}"
    base64_body = requests.get(url, headers={'Referer': "ya.ru"}).text
    if base64_body == 'video_not_found':
        return finded_videos
    items = json.loads(decode64(base64_body).replace('},]','}]'))['playlist']
    if season_id and episode_id:
        try:
            items = items[int(season_id)-1]['folder'][int(episode_id)-1]['folder']
        except:
            return finded_videos
    for item in items:
        title = item.get('title',False) or item.get('comment',False)
        video_url = item['file'].split(']')[-1]
        video_ext = video_url.split('.')[-1]
        finded_videos.append((f'({video_ext.upper()}): {title}',video_url,video_ext))
    return finded_videos


def prov_6(kp_id,season_id=False,episode_id=False):
    finded_videos = []
    try:
        prov = requests.Session()
        url = decode64('aHR0cHM6Ly9hcGkubW92aWVsYWIuZ3VydS9hcGkvdjEvbW92aWVzLw==')
        headers = json.loads(decode64('eyJ1c2VyLWFnZW50IjoiRGFydC8zLjUgKGRhcnQ6aW8pIiwicGxhdGZvcm0iOiJtb2JpbGUifQ=='))
        prov.headers.update(headers)
        body = prov.get(f'{url}{kp_id}').json()
        if not body.get('result',False):
            return []
        if season_id and episode_id:
            videos_info =body['result']['serial_episodes'][season_id]['episodes'][episode_id]['translations']
            items = [(x['name'],x['hash']) for x in videos_info.values()]
        else:
            items = [(body['result']['player']['translator'],body['result']['player']['token'])]
        for item in items:
            title,hash = item
            json_data = json.loads(decode64('eyJ0b2tlbiI6IjVjNzhhMGUwZTliYWEwMjM5YTYwYWQ1ZDRiMDBhNGI2Iiwia2V5IjoiZDYyMjQ2MTQzYzU3YTI3ZjFjMWZlNWU5YmJiODdkY2IifQ=='))
            params = json_data.copy()
            params['hash'] = hash
            params['s'] = int(season_id)
            params['e'] = int(episode_id)
            params['method'] = 'getkey'
            url = decode64('aHR0cHM6Ly9hcGl2Yi5jb20vYXBpL3BsYXlsaXN0Lmpzb24=')
            #url = decode64('aHR0cHM6Ly9hcGl2Yi5jb20vYXBpX3N5c3RlbS9nZXRmaWxlLnBocA==')
            body = prov.get(url, params=params).json()
            key = body['key']
            params = json_data.copy()
            params['hash'] = hash
            params['s'] = int(season_id)
            params['e'] = int(episode_id)
            params['key2'] = key
            video_url = prov.get(url, params=params).json()['url'] + '|' + '&'.join([f'{key}={value}' for key, value in headers.items()])
            finded_videos.append((f'(HLS): {title}',video_url,'hls'))
    finally:
        return finded_videos 


def rezka_clear(s):
    s = re.sub(r'//_//(?:JCQhIUAkJEBeIUAjJCRA|QEBAQEAhIyMhXl5e|IyMjI14hISMjIUBA|Xl5eIUAjIyEhIyM=|JCQjISFAIyFAIyM=)', '', s)[2:]
    return base64.b64decode(s).decode('utf-8', errors='ignore')


def rezka_parser(s,title='Оригинальная'):
    result = []
    pattern = re.compile(r'\[([0-9]+p)\]' r'(https://[^,\s]+\.mp4)' r'(?:[:][^,\s]+)?')
    matches = pattern.findall(s.replace('\\/', '/'))
    for res, url in matches:
        if res in ('360p','480p'):
            continue            
        result.append((f"(MP4): [{res}] {title}",url,'mp4'))        
    return result


def prov_5(kp_id, season_id='0',episode_id='0'):
    finded_videos = []
    body = requests.post(decode64('aHR0cHM6Ly9yZXlvaG9oby5zcGFjZS9jYWNoZQ=='), data={'kinopoisk': kp_id}).json()
    veoveo = [x for x in body if x['name']=='veoveo50']
    if veoveo:
        movie_id = veoveo[0]['iframe'].split('&token=')[0].split('movie_id=')[1]
        title = veoveo[0]['translate'][7:]
        url = 'https://api.rstprgapipt.com/dle-plugin/balancer-api/proxy/playlists/catalog-api/episodes'
        headers = {'dle-api-token': 'eyJhbGciOiJIUzI1NiJ9.eyJ3ZWJTaXRlIjoiNTUiLCJpc3MiOiJhcGktd2VibWFzdGVyIiwic3ViIjoiOTEiLCJpYXQiOjE3NTQ2ODUxODksImp0aSI6ImM0YTVjZTViLWZkNjgtNGE5Ni05YWE3LTkwOTYzYzM1ZGZmNiIsInNjb3BlIjoiRExFIn0.ZTrvBhRnCZjFSxRnEW7Vw2lOJE1AD8GO6C-LJKc_4WY','origin':'https://api.rstprgapipt.com'}
        params = {'content-id': movie_id,}
        episodes = requests.get(url,params=params,headers=headers).json()
        video_info = [x for x in episodes if str(x['order'])==episode_id and str(x['season']['order'])==season_id]
        if video_info:        
            if season_id and episode_id:
                video_url = video_info[0]['episodeVariants'][0]['filepath']
            else:
                video_url = video_info[0]['m3u8MasterFilePath']
            finded_videos.append((f'(MPD): {title}',video_url,'mpd'))
    return finded_videos


def prov_4(movie_name,movie_year,season_id=False,episode_id=False):
    from addon import kv_auth
    finded_videos = []
    prov = requests.Session()
    prov_url = decode64('aHR0cHM6Ly9hdG90by5ydS9hcGk=')
    prov.headers.update({'cookie': f'token={kv_auth["auth"]["token"]}','User-Agent':'App.krasview+1/1.1.68'})
    prov.cookies = requests.utils.cookiejar_from_dict(kv_auth['cookies'])
    json_data = {'page':'1','section':['movie','series'],'query':f'{movie_name} {movie_year}'}
    movies = prov.post(f'{prov_url}/channel/list', json=json_data).json()['data']
    if not movies:
        return finded_videos
    movies.sort(key=lambda x: x['id'])
    movie_page = movies[0]['address']
    body = prov.get(f'{prov_url}/channel/item/{movie_page}').json()
    try:
        if body['movie'] is None:
            seasons = [x for x in body['seasons'] if bool(re.search('(\d+)',x['title']))]
            season = [x['id'] for x in seasons if re.search('(\d+)',x['title'])[0]==season_id][0]
            video_id = prov.get(f'{prov_url}/channel/season/{season}').json()['video'][int(episode_id)-1]['v_id']
            movie_info = prov.get(f'{prov_url}/video/{video_id}').json()['video']
        else:
            movie_info = body['movie']
        video_title = movie_info['v_title'].replace('&quot;','"')
        audio_count = movie_info['audio']
        finded_videos.append((f'(MP4): {video_title} [озвучек - {audio_count}]',movie_info['url2'],'mp4'))
        finded_videos.append((f'(MPD): {video_title} [озвучек - {audio_count}]',movie_info['url1'],'mpd'))
    finally:
        return finded_videos


def prov_3(kp_id,season_id=False,episode_id=False):
    finded_videos = []
    try:
        response = requests.get(f'https://player.cdnvideohub.com/playerjs?partner=1&kid={kp_id}')
        if response.status_code==200:
            json_str = re.search("file: (.*)}\);",response.text,re.S).group(1)
            json_str = json_str.replace(' ','').replace('\n','').replace(',}','}').replace(',]',']').replace("'",'"')[:-1]
            videos = json.loads(json_str)
            if season_id and episode_id:
                urls = [x['file'] for x in videos[int(season_id)-1]['folder'] if re.search('\d+',x['title'])[0]==episode_id]
            else:
                urls = [x['file'] for x in videos[0]['folder']]
            for url_ind,url_str in enumerate(urls,1):
                finded_videos.append((f'(HLS): вариант №{url_ind}',url_str,'hls'))
    finally:
        return finded_videos 

 
def prov_2(kp_id,season_id=False,episode_id=False):
    finded_videos = []
    try:
        headers = {'Authorization':decode64('QmVhcmVyIDc2OTB8R3ZHZFhnczB1YWJvd0d5aEhHaGpXR3M5NUkweWM5ZzNpclFDY3ZTTDM3Y2QyZTJj')}
        vibix_url = requests.get(f'https://vibix.org/api/v1/publisher/videos/kp/{kp_id}', headers=headers).json().get('iframe_url',False)
        if not vibix_url:
            return finded_videos
        body = requests.get(vibix_url).text
        files_info = json.loads(re.search(',file:(.*)function getFileId',body,re.S).group(1)[:-5]+']')
        if season_id and episode_id:
            files_info = files_info[int(season_id)-1]['folder'][int(episode_id)-1]['folder']
        for item in files_info:
            title = item['title']
            videos_info = item['file']
            for video in videos_info.split(', '):
                video_size,video_url = video[1:].split(']')
                video_ext = video.split('.')[-1][:-1]
                finded_videos.append((f'({video_ext.upper()}): [{video_size}] {title}',video_url,video_ext.lower()))   
    finally:
        return finded_videos
        

def prov_1(kp_id,season_id=False,episode_id=False):
    finded_videos = []
    try:
        api_url = decode64('aHR0cHM6Ly9hcGkubHVtZXguc2l0ZQ==')
        prov = requests.Session()
        prov.timeout=5
        json_data = json.loads(decode64('eyJ1c2VybmFtZSI6ICJsbWRfaW50IiwgInBhc3N3b3JkIjogIkg5TjNjSlQxNGM1NCJ9'))
        body = prov.post(f'{api_url}/login', json=json_data).json()
        access_token = body['accessToken']
        refresh_token = body['refreshToken']
        access_token = prov.post(f'{api_url}/refresh', json={'token': refresh_token}).json()['accessToken']
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:134.0) Gecko/20100101 Firefox/134.0',
            'authorization': f'Bearer {access_token}',
        }
        prov.headers.update(headers)
        params = {
            'clientId': decode64('VW9xYWkxSFROQlpD'),
            'kpId': kp_id,
            'domain': 'lmd',
            'contentType': 'short',
        }
        videos_info = prov.get(f'{api_url}/stream', params=params)
        if videos_info.status_code != 200:
            return finded_videos
        else:
            items = videos_info.json()['player']['media']
            if (season_id and episode_id):
                try:
                    items = items[int(season_id)-1]['episodes'][int(episode_id)-1]['media']
                except:
                    return finded_videos
        for video in items:
            video_info = prov.post(f'{api_url}{video["playlist"]}')
            if video_info.status_code==200:
                finded_videos.append((f"(HLS): {video.get('translation_name','')}",'http:'+video_info.json()['url'],'hls'))
    finally:
        return finded_videos        


def get_video_urls(movie_name,movie_year):
    import xbmc
    from xbmcgui import DialogProgress
    result = []
    try:
        progress = DialogProgress()
        progress.create("Выполняется поиск", "Пожалуйста, подождите...")
        kp_id,kp_serial = get_kinopoisk_id(movie_name,movie_year)
        if not kp_id:
            return None
        elif kp_serial:
            return kp_id
        else:
            provs_with_args = [
#                (prov_8, (kp_id,),'Alloha'),
#                (prov_7, (kp_id,),'HDVideoBox'),
                (prov_1, (kp_id,),'VideoCDN'),
#                (prov_3, (kp_id,),'Videohub'),
                (prov_2, (kp_id,),'Vibix'),
                (prov_4, (movie_name, movie_year),'Krasview'),
                (prov_6, (kp_id,),'HDVB'),
                (prov_5, (kp_id,),'Veoveo'),
            ]
            for ind,provs in enumerate(provs_with_args):
                func, args, prov_name = provs
                if progress.iscanceled():
                    break
                percent = int((ind/len(provs_with_args))*100)
                progress.update(percent, f"Поиск в {prov_name}")
                videos = [(f'{prov_name} {x[0]}',x[1],x[2]) for x in func(*args)]
                result.extend(videos)
    finally:
        progress.close()
    xbmc.log(f"SANTAX: {result}", level=xbmc.LOGINFO)
    return result


def find_episode_videos(kp_id,season_id,episode_id,movie_name,movie_year):
    import xbmc
    from xbmcgui import DialogProgress
    result = []
    progress = DialogProgress()
    progress.create("Выполняется поиск", "Пожалуйста, подождите...")
    provs_with_args = [
#        (prov_8, (kp_id,season_id,episode_id,),'Alloha'),
#        (prov_7, (kp_id,season_id,episode_id,),'HDVideoBox'),
        (prov_1, (kp_id,season_id,episode_id,),'VideoCDN'),
#        (prov_3, (kp_id,season_id,episode_id,),'Videohub'),
        (prov_2, (kp_id,season_id,episode_id,),'Vibix'),
        (prov_4, (movie_name, movie_year,season_id,episode_id,),'Krasview'),
        (prov_6, (kp_id,season_id,episode_id,),'HDVB'),
        (prov_5, (kp_id,season_id,episode_id,),'Veoveo'),
    ]
    for ind,provs in enumerate(provs_with_args):
        func, args, prov_name = provs
        if progress.iscanceled():
            break
        percent = int((ind/len(provs_with_args))*100)
        progress.update(percent, f"Поиск в {prov_name}")
        videos = [(f'{prov_name} {x[0]}',x[1],x[2]) for x in func(*args)]
        result.extend(videos)
    progress.close()
    return result
    
    
