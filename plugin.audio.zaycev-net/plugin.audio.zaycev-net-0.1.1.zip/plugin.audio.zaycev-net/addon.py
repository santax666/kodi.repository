import re
import sys
import xbmcgui
import xbmcplugin
import xbmcaddon
import html
import hashlib
import requests
import time
from urllib.parse import urlencode, parse_qsl

ADDON = xbmcaddon.Addon()
URL = sys.argv[0]
HANDLE = int(sys.argv[1])
PARAMS = sys.argv[2]

API_URL = "https://api.zaycev.net/external"
HELLO_URL = API_URL + "/hello"
AUTH_URL = API_URL + "/auth"
TOP_URL = API_URL + "/top"
FRESH_URL = API_URL + "/fresh"
ARTIST_URL = API_URL + "/artist/{}/tracks"
MUSIC_SET_LIST_URL = API_URL + "/musicset/list"
MUSIC_SET_DETAIL_URL = API_URL + "/musicset/detail"
GENRE_LIST_URL = API_URL + "/genre/list"
GENRE_URL = API_URL + "/genre"
SEARCH_URL = API_URL + "/search"
PLAY_URL = API_URL + "/track/{}/play"

STATIC_KEY = "Fh6w165Fmub"


def duration_to_seconds(duration_str):
    parts = duration_str.split(':')
    return sum(int(p.split('.')[0]) * (60 ** (len(parts) - i - 1)) for i, p in enumerate(parts))


def clear_text(text):
    """Очищает текст от HTML-тегов и спецсимволов."""
    text = re.sub(r'<[^>]+>', '', text)
    text = html.unescape(text)
    text = text.replace('\xa0', ' ')
    text = ' '.join(text.split())    
    return text


class MusicLibrary:
    def __init__(self):
        self._session = None
        self._init_session()

    def _init_session(self):
        try:
            self._session = requests.Session()
            hello_token = self._session.get(HELLO_URL).json()['token']
            hash_str = hashlib.md5((hello_token + STATIC_KEY).encode()).hexdigest()
            params = {'code': hello_token, 'hash': hash_str, 'active_subscribe': 1}
            access_token = self._session.get(AUTH_URL, params=params).json()['token']            
            self._session.params = {'access_token': access_token, 'active_subscribe': 1}
        except Exception:
            self._session = None

    def _fetch_paginated_data(self, url, **params):
        """Универсальный метод для получения пагинированных данных."""
        return self._session.get(url, params=params).json()

    def get_popular(self, page=1):
        return self._fetch_paginated_data(TOP_URL, page=page)

    def get_new(self, page=1):
        return self._fetch_paginated_data(FRESH_URL, page=page)

    def get_genre_music(self, genre, page=1):
        return self._fetch_paginated_data(GENRE_URL, genre=genre, page=page)

    def get_genres(self):
        return self._session.get(GENRE_LIST_URL).json()

    def get_compilations(self, page=1):
        return self._session.get(MUSIC_SET_LIST_URL, params={'page': page}).json()

    def get_compilation_tracks(self, compilation_id):
        return self._session.get(MUSIC_SET_DETAIL_URL, params={'id': compilation_id}).json()

    def get_artist_tracks(self, artist_id, page=1):
        return self._fetch_paginated_data(ARTIST_URL.format(artist_id), page=page)

    def get_track_url(self, track_id):
        return self._session.get(PLAY_URL.format(track_id)).json()['url']

    def search(self, query, page=1):
        params = {'query': query, 'type': 'all', 'page': page}
        return self._fetch_paginated_data(SEARCH_URL, **params)


library = MusicLibrary()


def _create_media_item(item):
    """Объединенная функция для создания элементов артистов и сборников."""
    label = item.get('name', '')
    li = xbmcgui.ListItem(label=label)
    
    icon = item.get('imageUrlSquare200', '') or item.get('smallImageUri', '')
    fanart = item.get('imageUrlTop917', '')
    
    li.setArt({'icon': icon, 'fanart': fanart})
    tags = li.getVideoInfoTag()
    tags.setTitle(label)
    
    if 'artistNames' in item:
        tags.setArtists(item.get('artistNames', []))
    
    tags.setPlot(clear_text(item.get('about', '')))
    return li


def _create_music_item(item):
    track = item.get('track', '')
    artist = item.get('artistName', '')
    duration = duration_to_seconds(item.get('duration',''))
    label = f'{artist} - {track}'
    li = xbmcgui.ListItem(label=label)
    icon = item.get('trackImageUrl', '')
    fanart = item.get('artistImageUrlTop917', '')
    li.setArt({'icon': icon, 'fanart': fanart})
    tags = li.getMusicInfoTag()
    tags.setTitle(track)
    tags.setArtist(artist)
    tags.setDuration(duration)
    context_menu_items = [
        ('Об исполнителе', f'Container.Update({URL}?action=context_images&media_id={item["id"]})'),
        ('Треки исполнителя', f'Container.Update({URL}?action=artist_tracks&artist_id={item.get("artistId", "")})'),
        ('Похожее по названию песни', f'Container.Update({URL}?action=context_actors&media_id={item["id"]})'),
        ('Похожее по названию исполнителя', f'Container.Update({URL}?action=context_reviews&media_id={item["id"]})'),
        ('Найти похожие', f'Container.Update("{URL}?action=context_similar&media_id={item["id"]}")'),
    ]
    li.addContextMenuItems(context_menu_items)
    return li


def _create_default_item(item):
    label = item.get('name', '')
    li = xbmcgui.ListItem(label=label)
    return li


def add_music_item(item, mode, tag_type=False):
    item_creators = {
        'compilation': _create_media_item,
        'music': _create_music_item,
        'artist': _create_media_item
    }
    
    create_item = item_creators.get(tag_type, _create_default_item)
    li = create_item(item)
    
    if mode == 'play':
        li.setProperty('IsPlayable', 'true')
        track_id = item.get('id', '')
        if track_id:
            url_params = {'mode': 'resolve_track', 'track_id': track_id}
            url = f'{URL}?{urlencode(url_params)}'
            xbmcplugin.addDirectoryItem(HANDLE, url, li)
        else:
            xbmcplugin.addDirectoryItem(HANDLE, '', li)
    else:
        url_params = {'mode': mode}
        if 'id' in item:
            url_params['id'] = item['id']
        if 'url' in item:
            url_params['genre'] = item['url']
        if 'name' in item:
            url_params['genre_name'] = item['name']
        if mode == 'artist_tracks':
            url_params['artist_id'] = item['id']
        url = f'{URL}?{urlencode(url_params)}'
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)


def add_item(label, mode, cur_page='1', last_page='1', genre='', query='', artist_id=''):
    li = xbmcgui.ListItem(label=label)
    url_params = {'mode': mode, 'cur_page': cur_page, 'last_page': last_page, 'genre': genre}
    if query:
        url_params['query'] = query
    if artist_id:
        url_params['artist_id'] = artist_id
    url = f'{URL}?{urlencode(url_params)}'
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)


def resolve_track(track_id):
    """Разрешить URL трека и установить его для воспроизведения."""
    mp3_url = library.get_track_url(track_id)
    if mp3_url:
        li = xbmcgui.ListItem(path=mp3_url)
        #li.setProperty('IsPlayable', 'true')        
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
    else:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


def _add_backward_navigation(mode, cur_page, last_page, genre='', query='', artist_id=''):
    """Добавить элементы навигации назад."""
    if cur_page > 2:
        add_item('В начало', mode, cur_page=1, last_page=last_page, genre=genre, query=query, artist_id=artist_id)
    if cur_page > 1:
        add_item('Назад', mode, cur_page=cur_page-1, last_page=last_page, genre=genre, query=query, artist_id=artist_id)


def _add_forward_navigation(mode, cur_page, last_page, genre='', query='', artist_id=''):
    """Добавить элементы навигации вперед."""
    if cur_page < last_page:
        add_item('Дальше', mode, cur_page=cur_page+1, last_page=last_page, genre=genre, query=query, artist_id=artist_id)
    if last_page - cur_page > 1:
        add_item('В конец', mode, cur_page=last_page, last_page=last_page, genre=genre, query=query, artist_id=artist_id)


def show_main_menu():
    xbmcplugin.setPluginCategory(HANDLE, ADDON.getAddonInfo('name'))
    xbmcplugin.setContent(HANDLE, 'files')
    
    menu_items = [
        ('Поиск', 'search'),
        ('Популярное', 'popular'),
        ('Сборники', 'compilations'),
        ('Новинки', 'new'),
        ('Жанры', 'genres')
    ]
    
    for label, mode in menu_items:
        add_item(label, mode)
    
    xbmcplugin.endOfDirectory(HANDLE)


def show_genres():
    xbmcplugin.setPluginCategory(HANDLE, 'Жанры')
    xbmcplugin.setContent(HANDLE, 'genres')
    
    for genre in library.get_genres():
        add_music_item(genre, 'genre_music')
    
    xbmcplugin.endOfDirectory(HANDLE)


def show_search():
    keyboard = xbmc.Keyboard('', 'Введите поисковый запрос')
    keyboard.doModal()
    
    if keyboard.isConfirmed():
        query = keyboard.getText()
        if query:
            show_paginated_list('search_results', library.search, f'Поиск: {query}', 
                              content_type='music', query=query, page=1)


def show_compilation_tracks(compilation_id):
    xbmcplugin.setPluginCategory(HANDLE, 'Треки сборника')
    xbmcplugin.setContent(HANDLE, 'songs')
    
    data = library.get_compilation_tracks(compilation_id)
    
    for track in data.get('tracks', []):
        add_music_item(track, 'play', tag_type='music')
    
    xbmcplugin.endOfDirectory(HANDLE)


def show_artist_tracks(artist_id, page):
    """Показать треки артиста."""
    xbmcplugin.setPluginCategory(HANDLE, 'Треки артиста')
    xbmcplugin.setContent(HANDLE, 'songs')
    
    show_paginated_list('artist_tracks', library.get_artist_tracks, 'Треки артиста',
                       content_type='music', artist_id=artist_id, page=page)


def show_paginated_list(mode, fetch_method, category_label, content_type='music', genre='', page=1, query='', artist_id=''):
    xbmcplugin.setPluginCategory(HANDLE, category_label)
    xbmcplugin.setContent(HANDLE, 'songs' if content_type == 'music' else 'albums')
    
    if artist_id:
        data = fetch_method(artist_id, page)
    elif query:
        data = fetch_method(query, page)
    elif genre:
        data = fetch_method(genre, page)
    else:
        data = fetch_method(page)
    
    cur_page = int(data['page'])
    last_page = int(data.get('pagesCount', data.get('pageCount', 1)))
    
    _add_backward_navigation(mode, cur_page, last_page, genre, query, artist_id)
    
    if mode == 'search_results':
        for artist in data.get('artists', []):
            add_music_item(artist, 'artist_tracks', tag_type='artist')
        
        for track in data.get('tracks', []):
            add_music_item(track, 'play', tag_type='music')
    else:
        list_key = 'tracks' if content_type == 'music' else 'list'
        for item in data.get(list_key, []):
            add_music_item(item, 
                          'play' if content_type == 'music' else 'compilation_songs',
                          tag_type=content_type)
    
    _add_forward_navigation(mode, cur_page, last_page, genre, query, artist_id)
    xbmcplugin.endOfDirectory(HANDLE)


def router():
    xbmc.log(f"SANTAX: {PARAMS}", level=xbmc.LOGINFO)
    params = dict(parse_qsl(PARAMS.lstrip('?')))
    mode = params.get('mode', 'main')
    cur_page = int(params.get('cur_page', 1))
    genre = params.get('genre', '')
    genre_name = params.get('genre_name', '')
    compilation_id = params.get('id', '')
    artist_id = params.get('artist_id', '')
    query = params.get('query', '')
    track_id = params.get('track_id', '')

    
    # Обработка разрешения URL трека
    if mode == 'resolve_track' and track_id:
        resolve_track(track_id)
        return
    
    if mode == 'compilation_songs' and compilation_id:
        show_compilation_tracks(compilation_id)
        return
    
    if mode == 'artist_tracks' and artist_id:
        show_artist_tracks(artist_id, cur_page)
        return
    
    paginated_modes = {
        'popular': {
            'func': lambda: show_paginated_list('popular', library.get_popular, 'Популярное', page=cur_page),
            'requires_genre': False,
            'requires_query': False,
            'requires_artist': False
        },
        'new': {
            'func': lambda: show_paginated_list('new', library.get_new, 'Новинки', page=cur_page),
            'requires_genre': False,
            'requires_query': False,
            'requires_artist': False
        },
        'compilations': {
            'func': lambda: show_paginated_list('compilations', library.get_compilations, 'Сборники', 
                                               content_type='compilation', page=cur_page),
            'requires_genre': False,
            'requires_query': False,
            'requires_artist': False
        },
        'genre_music': {
            'func': lambda: show_paginated_list('genre_music', library.get_genre_music, 
                                               genre_name, genre=genre, page=cur_page),
            'requires_genre': True,
            'requires_query': False,
            'requires_artist': False
        },
        'search_results': {
            'func': lambda: show_paginated_list('search_results', library.search, f'Поиск: {query}',
                                               query=query, page=cur_page),
            'requires_genre': False,
            'requires_query': True,
            'requires_artist': False
        },
        'artist_tracks': {
            'func': lambda: show_paginated_list('artist_tracks', library.get_artist_tracks, 'Треки артиста',
                                               artist_id=artist_id, page=cur_page),
            'requires_genre': False,
            'requires_query': False,
            'requires_artist': True
        }
    }
    
    simple_modes = {
        'main': show_main_menu,
        'genres': show_genres,
        'search': show_search
    }
    
    if mode in paginated_modes:
        config = paginated_modes[mode]
        if config['requires_genre'] and not genre:
            show_main_menu()
        elif config['requires_query'] and not query:
            show_main_menu()
        elif config['requires_artist'] and not artist_id:
            show_main_menu()
        else:
            config['func']()
    elif mode in simple_modes:
        simple_modes[mode]()
    else:
        show_main_menu()


if __name__ == '__main__':
    router()