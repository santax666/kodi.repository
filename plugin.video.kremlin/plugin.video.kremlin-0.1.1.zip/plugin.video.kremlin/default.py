import os
import re
import sys
import xbmc
import xbmcgui
import requests
import xbmcplugin
import xbmcaddon
import urllib.parse

# Инициализация аддона
addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
addon_url = sys.argv[0]
addon_path = addon.getAddonInfo('path')
addon_name = addon.getAddonInfo('name')


CATEGORIES = {
    'video': {
        '/': 'Все материалы',
        '/section/speeches/': 'Выступления',
        '/section/conferences/': 'Совещания, встречи',
        '/section/interviews/': 'Встречи со СМИ'
    },
    # 'photo': {
        # '/': 'Все материалы',
        # '/section/trips/': 'Поездки',
        # '/section/conferences/': 'Совещания, встречи',
        # '/section/ceremonies/': 'Церемонии'
    # },
    'audio': {
        '/': 'Все материалы',
        '/section/speeches/': 'Выступления',
        '/section/conferences/': 'Совещания, встречи',
        '/section/interviews/': 'Встречи со СМИ'
    }
}

site_url = 'http://kremlin.ru'
site_headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36'}


def time_to_seconds(time_str):
    h, m, s = re.match(r'T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?', time_str).groups()
    return int(h or 0)*3600 + int(m or 0)*60 + int(s or 0)


class MediaPlugin:
    def __init__(self):
        self.base_url = addon_url
        
    def build_url(self, query):
        """Создание URL с параметрами"""
        return f'{self.base_url}?{urllib.parse.urlencode(query)}'
        
    def show_main_menu(self):
        """Главное меню"""
#        menus = [('Видеозаписи','video'),('Фотографии','photo'),('Аудиозаписи','audio'),('Поиск','search')]
        menus = [('Видеозаписи','video'),('Аудиозаписи','audio'),('Поиск','search')]
        for name, media_type in menus:
            url = self.build_url({'mode': 'category', 'type': media_type})
            list_item = xbmcgui.ListItem(name)
            xbmcplugin.addDirectoryItem(addon_handle,url,list_item,True)        
        xbmcplugin.endOfDirectory(addon_handle)
    
    def show_category(self, media_type):
        """Показ категорий для типа медиа"""
        if media_type == 'search':
            self.show_search()
        if media_type not in CATEGORIES:
            return
        categories = CATEGORIES[media_type]        
        for category_id, category_name in categories.items():
            url = self.build_url({'mode': 'content','type': media_type,'category': category_id})
            list_item = xbmcgui.ListItem(category_name)
            xbmcplugin.addDirectoryItem(addon_handle,url,list_item,True)        
        xbmcplugin.endOfDirectory(addon_handle)
    
    def show_content(self, media_type, category,page,last_page,test_items):
#        last_page,test_items = self._get_kremlin_content(media_type, category, page)
        xbmcplugin.setPluginCategory(addon_handle, CATEGORIES[media_type][category])
        xbmcplugin.setContent(addon_handle, media_type) 
        if page > 1:
            url = self.build_url({'mode': 'content','type': media_type,'category': category, 'page': 1})
            list_item = xbmcgui.ListItem("В начало")
            xbmcplugin.addDirectoryItem(addon_handle, url, list_item,True)
        if page > 2:
            url = self.build_url({'mode': 'content','type': media_type,'category': category, 'page': page-1})
            list_item = xbmcgui.ListItem("Назад")
            xbmcplugin.addDirectoryItem(addon_handle, url, list_item,True)
        for item in test_items:
            title, desc, image_url, video_url, pub_date,duration = item
            list_item = xbmcgui.ListItem(title)
            list_item.setContentLookup(False)
            list_item.setArt({'fanart': image_url, 'thumb': image_url})
            tags = list_item.getVideoInfoTag()
            tags.setTitle(title)
            tags.setPlot(desc)
            tags.setDuration(time_to_seconds(duration) or 0)
            tags.setPremiered(pub_date)
            xbmcplugin.addDirectoryItem(addon_handle, video_url, list_item)
        if (last_page - page) > 1:
            url = self.build_url({'mode': 'content','type': media_type,'category': category, 'page': page+1})
            list_item = xbmcgui.ListItem("Дальше")
            xbmcplugin.addDirectoryItem(addon_handle, url, list_item,True)
        if page != last_page:
            url = self.build_url({'mode': 'content','type': media_type,'category': category, 'page': last_page})
            list_item = xbmcgui.ListItem("В конец")
            xbmcplugin.addDirectoryItem(addon_handle, url, list_item,True)
        xbmcplugin.endOfDirectory(addon_handle)
    
    def show_search(self):
        """Показ поиска"""
        # Реализация поиска
        keyboard = xbmc.Keyboard('', 'Введите поисковый запрос')
        keyboard.doModal()        
        if keyboard.isConfirmed():
            search_query = keyboard.getText()
            if search_query:
                # Здесь логика поиска по всем медиа-типам
                self._perform_search(search_query)


    def _find_video_info(self, body, media_type):
        try:
            title = re.search(r'"og:title" content="(.*?)"/>', body).group(1)
        except:
            title = 'Название не найдено'
        try:
            desc = re.search(r'"og:description" content="(.*?)"/>', body).group(1)
        except:
            desc = ''
        try:
            image_url = re.search(r'"contentUrl" content="(.*?)"/>', body).group(1) if media_type=='video' else re.search(r'"og:image" content="(.*?)"/>', body).group(1)
        except:
            image_url = ''
        try:
            media_url = re.findall(rf'<source type="{media_type}.*?" src="(.*?)"', body)[-1]
        except:
            media_url = ''
        try:
            pub_date = re.search(r'"ya:ovs:upload_date" content="(.*?)"/>', body).group(1)
        except:
            pub_date = ''
        try:
            duration = re.search(r'<meta itemprop="duration" content="(.*?)"/>', body).group(1) if media_type=='video' else re.search(r' <span itemprop="duration" class="hidden duration" hidden="hidden">(.*?)</span>', body).group(1)
        except:
            duration = 'T1S'
        return [title, desc, image_url, media_url, pub_date,duration]

    

    def _get_kremlin_content(self, media_type, url):
        kremlin = requests.session()
        kremlin.headers = site_headers
        body = kremlin.get(url).text
        try:
            last_page = int(re.search(r'<link rel="last" href=".*?(\d+)"/>',body).group(1))
        except:
            last_page = 1
        items = []
        for data_id in re.findall(r'data-id=\"(\d+)\"', body):
            body = kremlin.get(f"{site_url}/misc/{data_id}/{media_type}s").text
            items.append(self._find_video_info(body,media_type))
        return last_page,items

    
    def _perform_search(self, query):
        """Выполнение поиска"""
        kremlin = requests.session()
        kremlin.headers = site_headers
        last_page,items = self._get_kremlin_content('video',f"{site_url}/search?section=video&query={query}")
        self.show_content('video','/', 1, last_page,items)

    
    def router(self, paramstring):
        """Маршрутизатор параметров"""
        params = dict(urllib.parse.parse_qsl(paramstring))        
        mode = params.get('mode', 'main')
        media_type = params.get('type', '')
        page = int(params.get('page', 1))
        if mode == 'main' or not mode:
            self.show_main_menu()
        elif mode == 'category':
            self.show_category(media_type)
        elif mode == 'content':
            category = params.get('category', '/')
            url = f"{site_url}/multimedia/{media_type}{category}page/{page}"
            last_page,items = self._get_kremlin_content(media_type, url)
            self.show_content(media_type, category, page, last_page,items)
        elif mode == 'search':
            self.show_search()

def run():
    """Запуск плагина"""
    plugin = MediaPlugin()
    plugin.router(sys.argv[2][1:])

if __name__ == '__main__':
    run()
